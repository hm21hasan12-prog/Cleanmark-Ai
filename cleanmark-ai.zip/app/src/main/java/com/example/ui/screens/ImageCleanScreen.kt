package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush as BrushGradient
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.CleanMode
import com.example.model.ComparisonMode
import com.example.model.ProcessingState
import com.example.ui.components.BeforeAfterSlider
import com.example.ui.components.ProcessingOverlay
import com.example.ui.components.WatermarkCanvasOverlay
import com.example.ui.components.WatermarkChipsRow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.CyanPrimaryVariant
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.RoseError
import com.example.ui.theme.VioletSecondary
import com.example.viewmodel.CleanMarkViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageCleanScreen(
    viewModel: CleanMarkViewModel,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val origBmp by viewModel.originalBitmap.collectAsStateWithLifecycle()
    val cleanBmp by viewModel.cleanedBitmap.collectAsStateWithLifecycle()
    val regions by viewModel.detectedRegions.collectAsStateWithLifecycle()
    val brushStrokes by viewModel.brushStrokes.collectAsStateWithLifecycle()
    val cleanMode by viewModel.cleanMode.collectAsStateWithLifecycle()
    val comparisonMode by viewModel.comparisonMode.collectAsStateWithLifecycle()
    val sliderPos by viewModel.sliderPosition.collectAsStateWithLifecycle()
    val brushRadius by viewModel.brushRadius.collectAsStateWithLifecycle()
    val isEraser by viewModel.isEraser.collectAsStateWithLifecycle()
    val processingState by viewModel.processingState.collectAsStateWithLifecycle()
    val title by viewModel.currentTitle.collectAsStateWithLifecycle()

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { viewModel.loadImageFromUri(it) }
    }

    Box(modifier = modifier.fillMaxSize().background(DarkBackground)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Top App Bar
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "CleanMark AI",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    // Pick from user device gallery
                    IconButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.testTag("pick_photo_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "Import Photo",
                            tint = CyanPrimary
                        )
                    }

                    // Save Cleaned
                    if (cleanBmp != null) {
                        IconButton(
                            onClick = { viewModel.saveCleanedResult() },
                            modifier = Modifier.testTag("save_photo_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.SaveAlt,
                                contentDescription = "Save image",
                                tint = EmeraldSuccess
                            )
                        }

                        IconButton(
                            onClick = { viewModel.shareCleanedResult() },
                            modifier = Modifier.testTag("share_photo_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share image",
                                tint = Color.White
                            )
                        }
                    }

                    // Settings
                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )

            // Preset Sample Selector Row (Allows instantaneous testing)
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
            ) {
                item {
                    Text(
                        text = "Presets:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(end = 4.dp, top = 8.dp)
                    )
                }
                item {
                    FilterChip(
                        selected = title == "Parisian Café",
                        onClick = { viewModel.loadPresetSample(CleanMarkViewModel.SamplePhotoType.CAFE_TIMESTAMP) },
                        label = { Text("Date Timestamp") },
                        leadingIcon = { Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(14.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanPrimary.copy(alpha = 0.2f),
                            selectedLabelColor = CyanPrimary
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = title == "Urban Portrait",
                        onClick = { viewModel.loadPresetSample(CleanMarkViewModel.SamplePhotoType.PORTRAIT_BADGE) },
                        label = { Text("Corner Badge") },
                        leadingIcon = { Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(14.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PurpleAccent.copy(alpha = 0.2f),
                            selectedLabelColor = PurpleAccent
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = title == "Tropical Resort",
                        onClick = { viewModel.loadPresetSample(CleanMarkViewModel.SamplePhotoType.STOCK_SYNTHETIC) },
                        label = { Text("Stock Watermark") },
                        leadingIcon = { Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(14.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VioletSecondary.copy(alpha = 0.2f),
                            selectedLabelColor = VioletSecondary
                        )
                    )
                }
            }

            // Mode Tabs (Auto Scan | Manual Brush | Box Drag | Compare)
            TabRow(
                selectedTabIndex = if (cleanBmp != null) 3 else when (cleanMode) {
                    CleanMode.AUTO_SCAN -> 0
                    CleanMode.BRUSH_ERASE -> 1
                    CleanMode.BOX_SELECT -> 2
                },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = CyanPrimary,
                indicator = { tabPositions ->
                    val tabIdx = if (cleanBmp != null) 3 else when (cleanMode) {
                        CleanMode.AUTO_SCAN -> 0
                        CleanMode.BRUSH_ERASE -> 1
                        CleanMode.BOX_SELECT -> 2
                    }
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[tabIdx]),
                        color = CyanPrimary
                    )
                }
            ) {
                Tab(
                    selected = cleanBmp == null && cleanMode == CleanMode.AUTO_SCAN,
                    onClick = { viewModel.setCleanMode(CleanMode.AUTO_SCAN) },
                    text = { Text("Auto AI", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("tab_auto_ai")
                )
                Tab(
                    selected = cleanBmp == null && cleanMode == CleanMode.BRUSH_ERASE,
                    onClick = { viewModel.setCleanMode(CleanMode.BRUSH_ERASE) },
                    text = { Text("Brush", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.Brush, null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("tab_brush")
                )
                Tab(
                    selected = cleanBmp == null && cleanMode == CleanMode.BOX_SELECT,
                    onClick = { viewModel.setCleanMode(CleanMode.BOX_SELECT) },
                    text = { Text("Box", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.CropFree, null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("tab_box")
                )
                Tab(
                    selected = cleanBmp != null,
                    onClick = {
                        if (cleanBmp == null) {
                            viewModel.cleanWatermarks()
                        }
                    },
                    text = { Text("Compare", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.Compare, null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("tab_compare")
                )
            }

            // Main Canvas / Split Slider Viewport
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                val currentOrig = origBmp
                val currentClean = cleanBmp

                if (currentOrig != null) {
                    if (currentClean != null) {
                        // Cleaned result comparison view
                        BeforeAfterSlider(
                            beforeBitmap = currentOrig,
                            afterBitmap = currentClean,
                            sliderPosition = sliderPos,
                            onSliderChange = { viewModel.setSliderPosition(it) },
                            comparisonMode = comparisonMode,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        // Interactive editing canvas view
                        WatermarkCanvasOverlay(
                            bitmap = currentOrig,
                            regions = regions,
                            brushStrokes = brushStrokes,
                            cleanMode = cleanMode,
                            brushRadius = brushRadius,
                            isEraser = isEraser,
                            onRegionToggle = { viewModel.toggleRegionSelection(it) },
                            onAddBrushStroke = { viewModel.addBrushStroke(it) },
                            onAddBoxRegion = { viewModel.addManualBoxRegion(it) },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            // Watermark Chips Row (when in auto scan or box select mode)
            if (cleanBmp == null && regions.isNotEmpty()) {
                WatermarkChipsRow(
                    regions = regions,
                    onToggle = { viewModel.toggleRegionSelection(it) },
                    onDelete = { viewModel.deleteRegion(it) }
                )
            }

            // Brush Tools Toolbar (when in Brush mode)
            AnimatedVisibility(visible = cleanBmp == null && cleanMode == CleanMode.BRUSH_ERASE) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Brush Size", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.width(8.dp))
                            Slider(
                                value = brushRadius,
                                onValueChange = { viewModel.setBrushRadius(it) },
                                valueRange = 0.015f..0.09f,
                                modifier = Modifier.weight(1f),
                                colors = SliderDefaults.colors(
                                    thumbColor = CyanPrimary,
                                    activeTrackColor = CyanPrimary
                                )
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = !isEraser,
                                    onClick = { viewModel.toggleEraser(false) },
                                    label = { Text("Mask") },
                                    leadingIcon = { Icon(Icons.Default.Brush, null, modifier = Modifier.size(14.dp)) }
                                )
                                FilterChip(
                                    selected = isEraser,
                                    onClick = { viewModel.toggleEraser(true) },
                                    label = { Text("Eraser") },
                                    leadingIcon = { Icon(Icons.Default.DeleteSweep, null, modifier = Modifier.size(14.dp)) }
                                )
                            }

                            Row {
                                IconButton(onClick = { viewModel.undoBrush() }) {
                                    Icon(Icons.AutoMirrored.Filled.Undo, "Undo", tint = Color.White)
                                }
                                IconButton(onClick = { viewModel.redoBrush() }) {
                                    Icon(Icons.AutoMirrored.Filled.Redo, "Redo", tint = Color.White)
                                }
                                IconButton(onClick = { viewModel.clearBrush() }) {
                                    Icon(Icons.Default.DeleteSweep, "Clear", tint = RoseError)
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Action Bar: Glowing "Clean Watermarks" Button
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (cleanBmp != null) {
                        FilledTonalButton(
                            onClick = { viewModel.autoScanWatermarks() },
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Re-Edit")
                        }

                        Button(
                            onClick = { viewModel.saveCleanedResult() },
                            modifier = Modifier.weight(1.5f).height(48.dp).testTag("save_result_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                        ) {
                            Icon(Icons.Default.SaveAlt, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save Clean Image", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = { viewModel.cleanWatermarks() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("clean_watermarks_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyanPrimary,
                                contentColor = Color.Black
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.CleaningServices,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            val activeCount = regions.count { it.isSelected } + (if (brushStrokes.isNotEmpty()) 1 else 0)
                            Text(
                                text = if (activeCount > 0) "Remove $activeCount Watermark(s)" else "Auto-Clean Watermarks",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Full Screen Processing Overlay
        ProcessingOverlay(state = processingState)
    }
}
