package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.example.ai.InpaintingEngine
import com.example.model.NormalizedRect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sin

data class VideoCleanProgress(
    val currentFrame: Int,
    val totalFrames: Int,
    val progress: Float,
    val fps: Float,
    val currentPreview: Bitmap? = null
)

object VideoCleanerEngine {

    /**
     * Generates a realistic synthetic test video frame sequence with an animated background
     * and a persistent corner watermark badge + timestamp, allowing instant out-of-the-box video testing.
     */
    fun generateSampleVideoFrames(frameCount: Int = 18, width: Int = 640, height: Int = 360): List<Bitmap> {
        val frames = mutableListOf<Bitmap>()
        for (i in 0 until frameCount) {
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)

            // Animated colorful gradient background (sunset moving ocean waves)
            val t = i.toFloat() / frameCount
            val skyColor = Color.rgb(
                (30 + 40 * sin(t * Math.PI)).toInt(),
                (60 + 70 * sin((t + 0.3) * Math.PI)).toInt(),
                (120 + 80 * sin((t + 0.6) * Math.PI)).toInt()
            )
            canvas.drawColor(skyColor)

            // Draw landscape elements (sun / moving boat / horizon)
            val sunPaint = Paint().apply {
                color = Color.rgb(255, 200, 100)
                isAntiAlias = true
            }
            val sunX = width * (0.3f + 0.4f * t)
            val sunY = height * 0.45f
            canvas.drawCircle(sunX, sunY, 40f, sunPaint)

            // Draw ocean waves
            val waterPaint = Paint().apply {
                color = Color.rgb(18, 52, 86)
                isAntiAlias = true
            }
            canvas.drawRect(0f, height * 0.55f, width.toFloat(), height.toFloat(), waterPaint)

            // Draw animated waves
            val wavePaint = Paint().apply {
                color = Color.argb(120, 255, 255, 255)
                strokeWidth = 4f
                style = Paint.Style.STROKE
            }
            for (w in 0 until width step 20) {
                val waveY = height * 0.58f + 10f * sin((w + i * 15) * 0.05f).toFloat()
                canvas.drawPoint(w.toFloat(), waveY, wavePaint)
            }

            // Draw PERSISTENT CORNER WATERMARK BADGE (Top-Right)
            val badgePaint = Paint().apply {
                color = Color.argb(200, 20, 20, 25)
                isAntiAlias = true
            }
            val bw = width * 0.28f
            val bh = height * 0.14f
            val bx = width - bw - 16f
            val by = 16f
            canvas.drawRoundRect(bx, by, bx + bw, by + bh, 12f, 12f, badgePaint)

            val textPaint = Paint().apply {
                color = Color.WHITE
                textSize = bh * 0.38f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("⚡ @viral_clip", bx + bw / 2f, by + bh * 0.62f, textPaint)

            // Draw bottom timestamp watermark
            val timePaint = Paint().apply {
                color = Color.rgb(255, 170, 0)
                textSize = 18f
                typeface = Typeface.MONOSPACE
                isAntiAlias = true
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText("REC 00:0$i / 00:18", width - 20f, height - 16f, timePaint)

            frames.add(bmp)
        }
        return frames
    }

    /**
     * Extracts frame samples from a video Uri using MediaMetadataRetriever.
     */
    suspend fun extractFramesFromUri(
        context: Context,
        videoUri: Uri,
        maxFrames: Int = 15
    ): List<Bitmap> = withContext(Dispatchers.IO) {
        val frames = mutableListOf<Bitmap>()
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, videoUri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val durationMs = durationStr?.toLongOrNull() ?: 5000L
            val stepMs = durationMs / maxFrames

            for (i in 0 until maxFrames) {
                val timeUs = (i * stepMs * 1000)
                val frame = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if (frame != null) {
                    frames.add(frame)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
        if (frames.isEmpty()) {
            // Fallback to sample frames if unable to read video
            generateSampleVideoFrames(maxFrames)
        } else {
            frames
        }
    }

    /**
     * Cleans a sequence of video frames by applying the watermark removal mask on each frame.
     */
    suspend fun cleanVideoFrames(
        frames: List<Bitmap>,
        regions: List<NormalizedRect>,
        onProgress: (VideoCleanProgress) -> Unit
    ): List<Bitmap> = withContext(Dispatchers.Default) {
        val cleanedList = mutableListOf<Bitmap>()
        val total = frames.size
        val startTime = System.currentTimeMillis()

        for (index in frames.indices) {
            val orig = frames[index]
            val cleaned = InpaintingEngine.inpaint(orig, regions)
            cleanedList.add(cleaned)

            val elapsedSec = (System.currentTimeMillis() - startTime) / 1000f
            val fps = if (elapsedSec > 0) (index + 1) / elapsedSec else 0f
            val progress = (index + 1).toFloat() / total

            onProgress(
                VideoCleanProgress(
                    currentFrame = index + 1,
                    totalFrames = total,
                    progress = progress,
                    fps = fps,
                    currentPreview = cleaned
                )
            )
        }
        cleanedList
    }

    /**
     * Saves cleaned video frames sequence to local cache folder.
     */
    suspend fun saveCleanedVideoFrames(
        context: Context,
        frames: List<Bitmap>,
        title: String
    ): String = withContext(Dispatchers.IO) {
        val folder = File(context.filesDir, "video_projects/${System.currentTimeMillis()}").apply { mkdirs() }
        for (i in frames.indices) {
            val file = File(folder, "frame_${String.format("%04d", i)}.jpg")
            FileOutputStream(file).use { out ->
                frames[i].compress(Bitmap.CompressFormat.JPEG, 88, out)
            }
        }
        folder.absolutePath
    }
}
