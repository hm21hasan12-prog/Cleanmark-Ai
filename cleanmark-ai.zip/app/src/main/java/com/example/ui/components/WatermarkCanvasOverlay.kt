package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.model.BrushStroke
import com.example.model.BrushStrokePoint
import com.example.model.CleanMode
import com.example.model.NormalizedRect
import com.example.model.WatermarkRegion
import com.example.model.WatermarkType
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.RoseError
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
fun WatermarkCanvasOverlay(
    bitmap: Bitmap,
    regions: List<WatermarkRegion>,
    brushStrokes: List<BrushStroke>,
    cleanMode: CleanMode,
    brushRadius: Float,
    isEraser: Boolean,
    onRegionToggle: (String) -> Unit,
    onAddBrushStroke: (BrushStroke) -> Unit,
    onAddBoxRegion: (NormalizedRect) -> Unit,
    modifier: Modifier = Modifier
) {
    val imageBitmap = remember(bitmap) { bitmap.asImageBitmap() }

    // Active drag stroke points for real-time brush drawing
    val activeStrokePoints = remember { mutableStateListOf<BrushStrokePoint>() }

    // Active drag rectangle for BOX_SELECT
    var dragStart by remember { mutableStateOf<Offset?>(null) }
    var dragCurrent by remember { mutableStateOf<Offset?>(null) }

    BoxWithConstraints(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(DarkBackground)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            .testTag("watermark_canvas_container")
    ) {
        val width = constraints.maxWidth.toFloat()
        val height = constraints.maxHeight.toFloat()

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(cleanMode, brushRadius, isEraser, width, height) {
                    when (cleanMode) {
                        CleanMode.AUTO_SCAN -> {
                            detectTapGestures { tapOffset ->
                                val normX = tapOffset.x / width
                                val normY = tapOffset.y / height
                                val tapped = regions.find { it.rect.contains(normX, normY) }
                                tapped?.let { onRegionToggle(it.id) }
                            }
                        }
                        CleanMode.BRUSH_ERASE -> {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    activeStrokePoints.clear()
                                    activeStrokePoints.add(
                                        BrushStrokePoint(offset.x / width, offset.y / height)
                                    )
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    activeStrokePoints.add(
                                        BrushStrokePoint(change.position.x / width, change.position.y / height)
                                    )
                                },
                                onDragEnd = {
                                    if (activeStrokePoints.isNotEmpty()) {
                                        onAddBrushStroke(
                                            BrushStroke(
                                                points = activeStrokePoints.toList(),
                                                strokeRadiusNormalized = brushRadius,
                                                isEraser = isEraser
                                            )
                                        )
                                        activeStrokePoints.clear()
                                    }
                                },
                                onDragCancel = { activeStrokePoints.clear() }
                            )
                        }
                        CleanMode.BOX_SELECT -> {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    dragStart = offset
                                    dragCurrent = offset
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    dragCurrent = change.position
                                },
                                onDragEnd = {
                                    val start = dragStart
                                    val curr = dragCurrent
                                    if (start != null && curr != null) {
                                        val minX = min(start.x, curr.x) / width
                                        val maxX = max(start.x, curr.x) / width
                                        val minY = min(start.y, curr.y) / height
                                        val maxY = max(start.y, curr.y) / height
                                        if (maxX - minX > 0.02f && maxY - minY > 0.02f) {
                                            onAddBoxRegion(
                                                NormalizedRect(
                                                    top = minY,
                                                    left = minX,
                                                    bottom = maxY,
                                                    right = maxX
                                                )
                                            )
                                        }
                                    }
                                    dragStart = null
                                    dragCurrent = null
                                },
                                onDragCancel = {
                                    dragStart = null
                                    dragCurrent = null
                                }
                            )
                        }
                    }
                }
        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // 1. Draw Source Image
            drawImage(
                image = imageBitmap,
                dstSize = IntSize(canvasWidth.roundToInt(), canvasHeight.roundToInt())
            )

            // 2. Draw Committed Brush Strokes
            for (stroke in brushStrokes) {
                if (stroke.points.isEmpty()) continue
                val strokeColor = if (stroke.isEraser) Color.Black.copy(alpha = 0.6f) else CyanPrimary.copy(alpha = 0.45f)
                val strokePx = stroke.strokeRadiusNormalized * 2f * min(canvasWidth, canvasHeight)

                if (stroke.points.size == 1) {
                    val p = stroke.points[0]
                    drawCircle(
                        color = strokeColor,
                        radius = stroke.strokeRadiusNormalized * min(canvasWidth, canvasHeight),
                        center = Offset(p.x * canvasWidth, p.y * canvasHeight)
                    )
                } else {
                    val path = Path()
                    path.moveTo(stroke.points[0].x * canvasWidth, stroke.points[0].y * canvasHeight)
                    for (i in 1 until stroke.points.size) {
                        path.lineTo(stroke.points[i].x * canvasWidth, stroke.points[i].y * canvasHeight)
                    }
                    drawPath(
                        path = path,
                        color = strokeColor,
                        style = Stroke(
                            width = strokePx,
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )
                }
            }

            // 3. Draw Active In-Progress Brush Stroke
            if (activeStrokePoints.isNotEmpty()) {
                val activeColor = if (isEraser) RoseError.copy(alpha = 0.6f) else PurpleAccent.copy(alpha = 0.6f)
                val strokePx = brushRadius * 2f * min(canvasWidth, canvasHeight)
                val path = Path()
                path.moveTo(activeStrokePoints[0].x * canvasWidth, activeStrokePoints[0].y * canvasHeight)
                for (i in 1 until activeStrokePoints.size) {
                    path.lineTo(activeStrokePoints[i].x * canvasWidth, activeStrokePoints[i].y * canvasHeight)
                }
                drawPath(
                    path = path,
                    color = activeColor,
                    style = Stroke(
                        width = strokePx,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }

            // 4. Draw Detected / Selected Watermark Regions (Bounding Boxes)
            val dashEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
            for (region in regions) {
                val rx = region.rect.left * canvasWidth
                val ry = region.rect.top * canvasHeight
                val rw = region.rect.width * canvasWidth
                val rh = region.rect.height * canvasHeight

                val boxColor = if (region.isSelected) {
                    when (region.type) {
                        WatermarkType.TIMESTAMP -> AmberWarning
                        WatermarkType.LOGO -> CyanPrimary
                        WatermarkType.STOCK_DIAGONAL -> PurpleAccent
                        WatermarkType.CUSTOM_BOX -> EmeraldSuccess
                        else -> CyanPrimary
                    }
                } else {
                    Color.Gray.copy(alpha = 0.4f)
                }

                // Semi-transparent highlight fill
                drawRoundRect(
                    color = boxColor.copy(alpha = if (region.isSelected) 0.28f else 0.08f),
                    topLeft = Offset(rx, ry),
                    size = Size(rw, rh),
                    cornerRadius = CornerRadius(8f, 8f)
                )

                // Dashed border
                drawRoundRect(
                    color = boxColor,
                    topLeft = Offset(rx, ry),
                    size = Size(rw, rh),
                    cornerRadius = CornerRadius(8f, 8f),
                    style = Stroke(width = 2.5f.dp.toPx(), pathEffect = dashEffect)
                )

                // Corner decorative handles
                val handleLen = min(rw, rh) * 0.25f
                val hStroke = 4f.dp.toPx()
                // Top-left
                drawLine(boxColor, Offset(rx, ry), Offset(rx + handleLen, ry), strokeWidth = hStroke)
                drawLine(boxColor, Offset(rx, ry), Offset(rx, ry + handleLen), strokeWidth = hStroke)
                // Bottom-right
                drawLine(boxColor, Offset(rx + rw, ry + rh), Offset(rx + rw - handleLen, ry + rh), strokeWidth = hStroke)
                drawLine(boxColor, Offset(rx + rw, ry + rh), Offset(rx + rw, ry + rh - handleLen), strokeWidth = hStroke)
            }

            // 5. Draw active box drag preview
            val s = dragStart
            val c = dragCurrent
            if (s != null && c != null) {
                val bx = min(s.x, c.x)
                val by = min(s.y, c.y)
                val bw = (max(s.x, c.x) - bx).coerceAtLeast(1f)
                val bh = (max(s.y, c.y) - by).coerceAtLeast(1f)

                drawRoundRect(
                    color = CyanPrimary.copy(alpha = 0.25f),
                    topLeft = Offset(bx, by),
                    size = Size(bw, bh),
                    cornerRadius = CornerRadius(8f, 8f)
                )
                drawRoundRect(
                    color = CyanPrimary,
                    topLeft = Offset(bx, by),
                    size = Size(bw, bh),
                    cornerRadius = CornerRadius(8f, 8f),
                    style = Stroke(width = 2.dp.toPx(), pathEffect = dashEffect)
                )
            }
        }
    }
}
