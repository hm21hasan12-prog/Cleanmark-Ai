package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CleanItemDao {
    @Query("SELECT * FROM cleaned_items ORDER BY timestamp DESC")
    fun getAllCleanedItems(): Flow<List<CleanItemEntity>>

    @Query("SELECT * FROM cleaned_items WHERE id = :id LIMIT 1")
    suspend fun getItemById(id: Long): CleanItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: CleanItemEntity): Long

    @Delete
    suspend fun deleteItem(item: CleanItemEntity)

    @Query("DELETE FROM cleaned_items WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT COUNT(*) FROM cleaned_items")
    suspend fun getCount(): Int
}
