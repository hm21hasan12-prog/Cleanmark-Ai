package com.example.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.ai.GeminiVisionService
import com.example.ai.InpaintingEngine
import com.example.data.local.AppDatabase
import com.example.data.local.CleanItemEntity
import com.example.data.local.CleanItemRepository
import com.example.model.BrushStroke
import com.example.model.BrushStrokePoint
import com.example.model.CleanMode
import com.example.model.ComparisonMode
import com.example.model.NormalizedRect
import com.example.model.ProcessingState
import com.example.model.WatermarkRegion
import com.example.model.WatermarkType
import com.example.util.BitmapUtils
import com.example.util.VideoCleanProgress
import com.example.util.VideoCleanerEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CleanMarkViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = CleanItemRepository(
        AppDatabase.getInstance(application).cleanItemDao(),
        application
    )

    val historyItems: StateFlow<List<CleanItemEntity>> = repository.allCleanedItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Image Processing State ---
    private val _originalBitmap = MutableStateFlow<Bitmap?>(null)
    val originalBitmap: StateFlow<Bitmap?> = _originalBitmap.asStateFlow()

    private val _cleanedBitmap = MutableStateFlow<Bitmap?>(null)
    val cleanedBitmap: StateFlow<Bitmap?> = _cleanedBitmap.asStateFlow()

    private val _currentTitle = MutableStateFlow("Untitled")
    val currentTitle: StateFlow<String> = _currentTitle.asStateFlow()

    private val _detectedRegions = MutableStateFlow<List<WatermarkRegion>>(emptyList())
    val detectedRegions: StateFlow<List<WatermarkRegion>> = _detectedRegions.asStateFlow()

    private val _brushStrokes = MutableStateFlow<List<BrushStroke>>(emptyList())
    val brushStrokes: StateFlow<List<BrushStroke>> = _brushStrokes.asStateFlow()

    private val _undoStack = mutableListOf<List<BrushStroke>>()
    private val _redoStack = mutableListOf<List<BrushStroke>>()

    private val _cleanMode = MutableStateFlow(CleanMode.AUTO_SCAN)
    val cleanMode: StateFlow<CleanMode> = _cleanMode.asStateFlow()

    private val _comparisonMode = MutableStateFlow(ComparisonMode.SPLIT_SLIDER)
    val comparisonMode: StateFlow<ComparisonMode> = _comparisonMode.asStateFlow()

    private val _sliderPosition = MutableStateFlow(0.5f)
    val sliderPosition: StateFlow<Float> = _sliderPosition.asStateFlow()

    private val _brushRadius = MutableStateFlow(0.035f)
    val brushRadius: StateFlow<Float> = _brushRadius.asStateFlow()

    private val _isEraser = MutableStateFlow(false)
    val isEraser: StateFlow<Boolean> = _isEraser.asStateFlow()

    private val _processingState = MutableStateFlow<ProcessingState>(ProcessingState.Idle)
    val processingState: StateFlow<ProcessingState> = _processingState.asStateFlow()

    // --- Video Processing State ---
    private val _videoFrames = MutableStateFlow<List<Bitmap>>(emptyList())
    val videoFrames: StateFlow<List<Bitmap>> = _videoFrames.asStateFlow()

    private val _cleanedVideoFrames = MutableStateFlow<List<Bitmap>>(emptyList())
    val cleanedVideoFrames: StateFlow<List<Bitmap>> = _cleanedVideoFrames.asStateFlow()

    private val _currentVideoFrame = MutableStateFlow(0)
    val currentVideoFrame: StateFlow<Int> = _currentVideoFrame.asStateFlow()

    private val _isVideoPlaying = MutableStateFlow(false)
    val isVideoPlaying: StateFlow<Boolean> = _isVideoPlaying.asStateFlow()

    private val _videoRegions = MutableStateFlow<List<NormalizedRect>>(
        listOf(NormalizedRect(top = 0.04f, left = 0.68f, bottom = 0.18f, right = 0.96f))
    )
    val videoRegions: StateFlow<List<NormalizedRect>> = _videoRegions.asStateFlow()

    private val _videoCleanProgress = MutableStateFlow<VideoCleanProgress?>(null)
    val videoCleanProgress: StateFlow<VideoCleanProgress?> = _videoCleanProgress.asStateFlow()

    private var videoPlaybackJob: Job? = null

    // --- Settings ---
    private val _useGeminiVision = MutableStateFlow(true)
    val useGeminiVision: StateFlow<Boolean> = _useGeminiVision.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    init {
        // Automatically load a sample photo on startup so the app is immediately interactive!
        loadPresetSample(SamplePhotoType.CAFE_TIMESTAMP)
        loadSampleVideo()
    }

    enum class SamplePhotoType {
        CAFE_TIMESTAMP,
        PORTRAIT_BADGE,
        STOCK_SYNTHETIC
    }

    fun loadPresetSample(type: SamplePhotoType) {
        viewModelScope.launch {
            _processingState.value = ProcessingState.Scanning(0.2f, "Loading sample photo...")
            _cleanedBitmap.value = null
            _detectedRegions.value = emptyList()
            _brushStrokes.value = emptyList()
            _undoStack.clear()
            _redoStack.clear()

            val context = getApplication<Application>()
            val bitmap = when (type) {
                SamplePhotoType.CAFE_TIMESTAMP -> {
                    _currentTitle.value = "Parisian Café"
                    BitmapUtils.loadBitmapFromResource(context, R.drawable.sample_cafe_timestamp_1790438047748)
                }
                SamplePhotoType.PORTRAIT_BADGE -> {
                    _currentTitle.value = "Urban Portrait"
                    BitmapUtils.loadBitmapFromResource(context, R.drawable.sample_portrait_logo_1790438060103)
                }
                SamplePhotoType.STOCK_SYNTHETIC -> {
                    _currentTitle.value = "Tropical Resort"
                    val base = BitmapUtils.loadBitmapFromResource(context, R.drawable.hero_banner_1790438097092)
                    if (base != null) {
                        BitmapUtils.stampWatermarks(base, addTimestamp = true, addDiagonalStock = true, addCornerBadge = true)
                    } else null
                }
            }

            if (bitmap != null) {
                _originalBitmap.value = bitmap
                _processingState.value = ProcessingState.Idle
                // Trigger auto detection
                autoScanWatermarks()
            } else {
                _processingState.value = ProcessingState.Error("Failed to load sample image")
            }
        }
    }

    fun loadImageFromUri(uri: Uri) {
        viewModelScope.launch {
            _processingState.value = ProcessingState.Scanning(0.2f, "Reading image file...")
            _cleanedBitmap.value = null
            _detectedRegions.value = emptyList()
            _brushStrokes.value = emptyList()
            _undoStack.clear()
            _redoStack.clear()
            _currentTitle.value = "Imported Image"

            val bitmap = BitmapUtils.loadBitmapFromUri(getApplication(), uri)
            if (bitmap != null) {
                _originalBitmap.value = bitmap
                _processingState.value = ProcessingState.Idle
                autoScanWatermarks()
            } else {
                _processingState.value = ProcessingState.Error("Could not read image format")
            }
        }
    }

    fun autoScanWatermarks() {
        val bmp = _originalBitmap.value ?: return
        viewModelScope.launch {
            _processingState.value = ProcessingState.Scanning(0.3f, "AI analyzing watermarks & timestamps...")
            try {
                val regions = if (_useGeminiVision.value) {
                    GeminiVisionService.detectWatermarks(bmp)
                } else {
                    GeminiVisionService.runHeuristicDetector(bmp)
                }
                _detectedRegions.value = regions
                _processingState.value = ProcessingState.Idle
                if (regions.isNotEmpty()) {
                    _feedbackMessage.value = "Detected ${regions.size} watermark(s) automatically!"
                } else {
                    _feedbackMessage.value = "No watermarks detected. Use the brush tool to mark areas."
                }
            } catch (e: Exception) {
                Log.e("CleanMarkVM", "Scan error", e)
                val fallback = GeminiVisionService.runHeuristicDetector(bmp)
                _detectedRegions.value = fallback
                _processingState.value = ProcessingState.Idle
            }
        }
    }

    fun cleanWatermarks() {
        val orig = _originalBitmap.value ?: return
        val activeRegions = _detectedRegions.value.filter { it.isSelected }.map { it.rect }
        val strokes = _brushStrokes.value

        if (activeRegions.isEmpty() && strokes.isEmpty()) {
            _feedbackMessage.value = "Please select or brush over a watermark to remove."
            return
        }

        viewModelScope.launch {
            _processingState.value = ProcessingState.Cleaning(0.1f, "Applying AI content-aware inpainting...")
            val result = InpaintingEngine.inpaint(
                source = orig,
                regions = activeRegions,
                brushStrokes = strokes,
                onProgress = { p ->
                    _processingState.value = ProcessingState.Cleaning(p, "Inpainting textures (${(p * 100).toInt()}%)...")
                }
            )
            _cleanedBitmap.value = result
            _sliderPosition.value = 0.5f
            _processingState.value = ProcessingState.Success("Watermark cleaned seamlessly!")
            _feedbackMessage.value = "Watermarks removed! Drag slider to compare."
        }
    }

    fun toggleRegionSelection(regionId: String) {
        _detectedRegions.value = _detectedRegions.value.map {
            if (it.id == regionId) it.copy(isSelected = !it.isSelected) else it
        }
    }

    fun deleteRegion(regionId: String) {
        _detectedRegions.value = _detectedRegions.value.filter { it.id != regionId }
    }

    fun addManualBoxRegion(rect: NormalizedRect) {
        val newRegion = WatermarkRegion(
            label = "Custom Box",
            type = WatermarkType.CUSTOM_BOX,
            rect = rect,
            confidence = 1.0f,
            isSelected = true
        )
        _detectedRegions.value = _detectedRegions.value + newRegion
    }

    fun addBrushStroke(stroke: BrushStroke) {
        _undoStack.add(_brushStrokes.value)
        _redoStack.clear()
        _brushStrokes.value = _brushStrokes.value + stroke
    }

    fun undoBrush() {
        if (_undoStack.isNotEmpty()) {
            _redoStack.add(_brushStrokes.value)
            _brushStrokes.value = _undoStack.removeAt(_undoStack.size - 1)
        }
    }

    fun redoBrush() {
        if (_redoStack.isNotEmpty()) {
            _undoStack.add(_brushStrokes.value)
            _brushStrokes.value = _redoStack.removeAt(_redoStack.size - 1)
        }
    }

    fun clearBrush() {
        if (_brushStrokes.value.isNotEmpty()) {
            _undoStack.add(_brushStrokes.value)
            _redoStack.clear()
            _brushStrokes.value = emptyList()
        }
    }

    fun setCleanMode(mode: CleanMode) {
        _cleanMode.value = mode
    }

    fun setComparisonMode(mode: ComparisonMode) {
        _comparisonMode.value = mode
    }

    fun setSliderPosition(pos: Float) {
        _sliderPosition.value = pos.coerceIn(0f, 1f)
    }

    fun setBrushRadius(rad: Float) {
        _brushRadius.value = rad.coerceIn(0.01f, 0.12f)
    }

    fun toggleEraser(isEraser: Boolean) {
        _isEraser.value = isEraser
    }

    fun setUseGeminiVision(enabled: Boolean) {
        _useGeminiVision.value = enabled
    }

    fun dismissFeedback() {
        _feedbackMessage.value = null
    }

    fun saveCleanedResult() {
        val orig = _originalBitmap.value ?: return
        val clean = _cleanedBitmap.value ?: return
        viewModelScope.launch {
            _processingState.value = ProcessingState.Cleaning(0.5f, "Saving to library & gallery...")
            val tags = _detectedRegions.value.filter { it.isSelected }.joinToString(", ") { it.label }
                .ifEmpty { "Manual Brush Erase" }
            val count = _detectedRegions.value.count { it.isSelected } + (if (_brushStrokes.value.isNotEmpty()) 1 else 0)

            repository.saveCleanedImage(
                originalBitmap = orig,
                cleanedBitmap = clean,
                title = _currentTitle.value,
                watermarkTags = tags,
                watermarksRemoved = count
            )

            val galleryUri = BitmapUtils.saveToGallery(getApplication(), clean, _currentTitle.value)
            _processingState.value = ProcessingState.Success("Saved to gallery and project history!")
            _feedbackMessage.value = if (galleryUri != null) "Saved to Pictures/CleanMark!" else "Saved to Project History!"
        }
    }

    fun shareCleanedResult() {
        val clean = _cleanedBitmap.value ?: return
        BitmapUtils.shareBitmap(getApplication(), clean, "Cleaned image without watermarks")
    }

    fun deleteHistoryProject(item: CleanItemEntity) {
        viewModelScope.launch {
            repository.delete(item)
            _feedbackMessage.value = "Project deleted"
        }
    }

    // --- VIDEO CLEANER ACTIONS ---
    fun loadSampleVideo() {
        viewModelScope.launch {
            val frames = VideoCleanerEngine.generateSampleVideoFrames(18)
            _videoFrames.value = frames
            _cleanedVideoFrames.value = emptyList()
            _currentVideoFrame.value = 0
            _videoRegions.value = listOf(
                NormalizedRect(top = 0.04f, left = 0.68f, bottom = 0.18f, right = 0.96f),
                NormalizedRect(top = 0.90f, left = 0.65f, bottom = 0.97f, right = 0.97f)
            )
        }
    }

    fun loadVideoFromUri(uri: Uri) {
        viewModelScope.launch {
            _processingState.value = ProcessingState.Scanning(0.3f, "Extracting video frames...")
            val frames = VideoCleanerEngine.extractFramesFromUri(getApplication(), uri, maxFrames = 20)
            _videoFrames.value = frames
            _cleanedVideoFrames.value = emptyList()
            _currentVideoFrame.value = 0
            _processingState.value = ProcessingState.Idle
            _feedbackMessage.value = "Extracted ${frames.size} video keyframes. Ready to clean!"
        }
    }

    fun cleanVideo() {
        val frames = _videoFrames.value
        val regions = _videoRegions.value
        if (frames.isEmpty()) return

        viewModelScope.launch {
            _processingState.value = ProcessingState.Cleaning(0.1f, "Processing video frames...")
            val cleaned = VideoCleanerEngine.cleanVideoFrames(
                frames = frames,
                regions = regions,
                onProgress = { progress ->
                    _videoCleanProgress.value = progress
                    _processingState.value = ProcessingState.Cleaning(
                        progress.progress,
                        "Cleaning frame ${progress.currentFrame}/${progress.totalFrames} (${String.format("%.1f", progress.fps)} FPS)"
                    )
                }
            )
            _cleanedVideoFrames.value = cleaned
            _processingState.value = ProcessingState.Success("Video cleaned! ${frames.size} frames processed.")
            _feedbackMessage.value = "Video watermark removed across all frames! Tap Play to review."
            startVideoPlayback()
        }
    }

    fun toggleVideoPlay() {
        if (_isVideoPlaying.value) {
            pauseVideoPlayback()
        } else {
            startVideoPlayback()
        }
    }

    fun startVideoPlayback() {
        _isVideoPlaying.value = true
        videoPlaybackJob?.cancel()
        videoPlaybackJob = viewModelScope.launch {
            val total = if (_cleanedVideoFrames.value.isNotEmpty()) _cleanedVideoFrames.value.size else _videoFrames.value.size
            if (total == 0) return@launch

            while (_isVideoPlaying.value) {
                delay(120) // ~8-10 fps playback for preview
                _currentVideoFrame.value = (_currentVideoFrame.value + 1) % total
            }
        }
    }

    fun pauseVideoPlayback() {
        _isVideoPlaying.value = false
        videoPlaybackJob?.cancel()
    }

    fun seekVideoFrame(index: Int) {
        val total = if (_cleanedVideoFrames.value.isNotEmpty()) _cleanedVideoFrames.value.size else _videoFrames.value.size
        if (total > 0) {
            _currentVideoFrame.value = index.coerceIn(0, total - 1)
        }
    }

    fun updateVideoRegion(rect: NormalizedRect) {
        _videoRegions.value = listOf(rect)
    }

    override fun onCleared() {
        super.onCleared()
        videoPlaybackJob?.cancel()
    }
}
