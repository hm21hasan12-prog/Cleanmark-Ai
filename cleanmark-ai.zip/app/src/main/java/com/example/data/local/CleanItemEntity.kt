package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cleaned_items")
data class CleanItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val mediaType: String, // "IMAGE" or "VIDEO"
    val originalPath: String,
    val cleanedPath: String,
    val watermarkTags: String,
    val watermarksRemoved: Int,
    val durationSeconds: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis()
)
