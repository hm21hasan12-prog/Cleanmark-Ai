package com.example.model

enum class WatermarkType {
    TIMESTAMP,
    LOGO,
    TEXT,
    STOCK_DIAGONAL,
    SUBTITLE,
    CUSTOM_BRUSH,
    CUSTOM_BOX
}

data class NormalizedRect(
    val top: Float,
    val left: Float,
    val bottom: Float,
    val right: Float
) {
    val width: Float get() = (right - left).coerceAtLeast(0.001f)
    val height: Float get() = (bottom - top).coerceAtLeast(0.001f)
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f

    fun contains(x: Float, y: Float): Boolean {
        return x in left..right && y in top..bottom
    }

    fun toPixelRect(bitmapWidth: Int, bitmapHeight: Int): android.graphics.Rect {
        val l = (left * bitmapWidth).toInt().coerceIn(0, bitmapWidth - 1)
        val t = (top * bitmapHeight).toInt().coerceIn(0, bitmapHeight - 1)
        val r = (right * bitmapWidth).toInt().coerceIn(l + 1, bitmapWidth)
        val b = (bottom * bitmapHeight).toInt().coerceIn(t + 1, bitmapHeight)
        return android.graphics.Rect(l, t, r, b)
    }
}

data class WatermarkRegion(
    val id: String = java.util.UUID.randomUUID().toString(),
    val label: String,
    val type: WatermarkType,
    val rect: NormalizedRect,
    val confidence: Float = 0.95f,
    val isSelected: Boolean = true
)

data class BrushStrokePoint(
    val x: Float, // Normalized 0..1
    val y: Float  // Normalized 0..1
)

data class BrushStroke(
    val id: String = java.util.UUID.randomUUID().toString(),
    val points: List<BrushStrokePoint>,
    val strokeRadiusNormalized: Float = 0.035f,
    val isEraser: Boolean = false
)

enum class CleanMode {
    AUTO_SCAN,
    BRUSH_ERASE,
    BOX_SELECT
}

enum class ComparisonMode {
    SPLIT_SLIDER,
    SIDE_BY_SIDE,
    BEFORE_ONLY,
    AFTER_ONLY
}

enum class MediaType {
    IMAGE,
    VIDEO
}

sealed class ProcessingState {
    object Idle : ProcessingState()
    data class Scanning(val progress: Float = 0f, val message: String = "Analyzing image...") : ProcessingState()
    data class Cleaning(val progress: Float = 0f, val message: String = "Inpainting watermarks...") : ProcessingState()
    data class Success(val message: String = "Cleaned successfully!") : ProcessingState()
    data class Error(val error: String) : ProcessingState()
}
