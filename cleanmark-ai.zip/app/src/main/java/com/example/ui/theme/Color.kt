package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette - CleanMark AI
val CyanPrimary = Color(0xFF00E5FF)
val CyanPrimaryVariant = Color(0xFF00B0FF)
val VioletSecondary = Color(0xFF8B5CF6)
val PurpleAccent = Color(0xFFA855F7)
val EmeraldSuccess = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RoseError = Color(0xFFF43F5E)

// Dark Theme Colors (Primary experience for media editor)
val DarkBackground = Color(0xFF0A0E17)
val DarkSurface = Color(0xFF131A29)
val DarkSurfaceVariant = Color(0xFF1D283E)
val DarkSurfaceBorder = Color(0xFF283654)
val DarkTextPrimary = Color(0xFFF1F5F9)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextMuted = Color(0xFF64748B)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightSurfaceBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
