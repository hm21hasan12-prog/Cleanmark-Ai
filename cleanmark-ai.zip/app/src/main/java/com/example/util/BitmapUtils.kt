package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BitmapUtils {

    suspend fun loadBitmapFromUri(context: Context, uri: Uri, maxDimension: Int = 1920): Bitmap? =
        withContext(Dispatchers.IO) {
            try {
                var input: InputStream? = context.contentResolver.openInputStream(uri)
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeStream(input, null, options)
                input?.close()

                var inSampleSize = 1
                while ((options.outWidth / inSampleSize) > maxDimension || (options.outHeight / inSampleSize) > maxDimension) {
                    inSampleSize *= 2
                }

                input = context.contentResolver.openInputStream(uri)
                val decodeOptions = BitmapFactory.Options().apply {
                    this.inSampleSize = inSampleSize
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                val bitmap = BitmapFactory.decodeStream(input, null, decodeOptions)
                input?.close()
                bitmap
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }

    suspend fun loadBitmapFromResource(context: Context, resId: Int, maxDimension: Int = 1920): Bitmap? =
        withContext(Dispatchers.IO) {
            try {
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeResource(context.resources, resId, options)

                var inSampleSize = 1
                while ((options.outWidth / inSampleSize) > maxDimension || (options.outHeight / inSampleSize) > maxDimension) {
                    inSampleSize *= 2
                }

                val decodeOptions = BitmapFactory.Options().apply {
                    this.inSampleSize = inSampleSize
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                BitmapFactory.decodeResource(context.resources, resId, decodeOptions)
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }

    /**
     * Stamps an existing bitmap with a watermark (for demo / simulation testing).
     */
    fun stampWatermarks(
        source: Bitmap,
        addTimestamp: Boolean = true,
        addDiagonalStock: Boolean = true,
        addCornerBadge: Boolean = true
    ): Bitmap {
        val result = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val w = result.width
        val h = result.height

        if (addDiagonalStock) {
            val textPaint = Paint().apply {
                color = Color.argb(110, 255, 255, 255)
                textSize = (w * 0.08f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
                setShadowLayer(6f, 2f, 2f, Color.argb(120, 0, 0, 0))
            }
            canvas.save()
            canvas.rotate(-30f, w / 2f, h / 2f)
            canvas.drawText("SHUTTERPHOTO • PREVIEW", w / 2f, h / 2f, textPaint)
            canvas.drawText("WATERMARK REMOVE DEMO", w / 2f, (h / 2f) + (w * 0.12f), textPaint)
            canvas.restore()
        }

        if (addTimestamp) {
            val stampPaint = Paint().apply {
                color = Color.rgb(255, 165, 0) // Camera digital orange
                textSize = (w * 0.045f)
                typeface = Typeface.MONOSPACE
                isAntiAlias = true
                textAlign = Paint.Align.RIGHT
                setShadowLayer(4f, 2f, 2f, Color.BLACK)
            }
            val dateStr = SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.US).format(Date())
            canvas.drawText(dateStr, w * 0.94f, h * 0.93f, stampPaint)
        }

        if (addCornerBadge) {
            // Draw a social watermark badge in top right corner
            val badgePaint = Paint().apply {
                color = Color.argb(180, 20, 20, 30)
                isAntiAlias = true
            }
            val pad = w * 0.03f
            val badgeW = w * 0.22f
            val badgeH = h * 0.08f
            val left = w - badgeW - pad
            val top = pad
            canvas.drawRoundRect(left, top, left + badgeW, top + badgeH, 16f, 16f, badgePaint)

            val logoPaint = Paint().apply {
                color = Color.WHITE
                textSize = (badgeH * 0.42f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("@creator_reel", left + badgeW / 2f, top + badgeH * 0.62f, logoPaint)
        }

        return result
    }

    /**
     * Saves bitmap to device MediaStore (Pictures/CleanMark).
     */
    suspend fun saveToGallery(context: Context, bitmap: Bitmap, title: String): Uri? =
        withContext(Dispatchers.IO) {
            try {
                val filename = "CleanMark_${System.currentTimeMillis()}.jpg"
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CleanMark")
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                }

                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                    ?: return@withContext null

                resolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                }
                uri
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }

    /**
     * Shares a bitmap via Android Share Sheet.
     */
    fun shareBitmap(context: Context, bitmap: Bitmap, title: String = "Cleaned with CleanMark AI") {
        try {
            val cachePath = File(context.cacheDir, "images").apply { mkdirs() }
            val file = File(cachePath, "cleaned_share_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
            }

            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "Look at this cleaned image! Watermarks removed automatically by CleanMark AI.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, title).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
