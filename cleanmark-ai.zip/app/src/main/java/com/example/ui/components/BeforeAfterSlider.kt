package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ComparisonMode
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.EmeraldSuccess
import kotlin.math.roundToInt

@Composable
fun BeforeAfterSlider(
    beforeBitmap: Bitmap,
    afterBitmap: Bitmap,
    sliderPosition: Float,
    onSliderChange: (Float) -> Unit,
    comparisonMode: ComparisonMode = ComparisonMode.SPLIT_SLIDER,
    modifier: Modifier = Modifier
) {
    val beforeImage = remember(beforeBitmap) { beforeBitmap.asImageBitmap() }
    val afterImage = remember(afterBitmap) { afterBitmap.asImageBitmap() }

    BoxWithConstraints(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(DarkBackground)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            .testTag("before_after_slider_container")
    ) {
        val containerWidth = constraints.maxWidth.toFloat()
        val containerHeight = constraints.maxHeight.toFloat()

        when (comparisonMode) {
            ComparisonMode.BEFORE_ONLY -> {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawImage(
                        image = beforeImage,
                        dstSize = IntSize(containerWidth.roundToInt(), containerHeight.roundToInt())
                    )
                }
                BadgeTag(
                    text = "ORIGINAL (WATERMARKED)",
                    color = AmberWarning,
                    modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
                )
            }
            ComparisonMode.AFTER_ONLY -> {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawImage(
                        image = afterImage,
                        dstSize = IntSize(containerWidth.roundToInt(), containerHeight.roundToInt())
                    )
                }
                BadgeTag(
                    text = "CLEANED (AI INPAINTED)",
                    color = EmeraldSuccess,
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                )
            }
            ComparisonMode.SIDE_BY_SIDE -> {
                Row(modifier = Modifier.fillMaxSize()) {
                    Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawImage(
                                image = beforeImage,
                                dstSize = IntSize((containerWidth / 2f).roundToInt(), containerHeight.roundToInt())
                            )
                        }
                        BadgeTag(text = "BEFORE", color = AmberWarning, modifier = Modifier.align(Alignment.TopStart).padding(8.dp))
                    }
                    Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawImage(
                                image = afterImage,
                                dstSize = IntSize((containerWidth / 2f).roundToInt(), containerHeight.roundToInt())
                            )
                        }
                        BadgeTag(text = "CLEANED", color = EmeraldSuccess, modifier = Modifier.align(Alignment.TopEnd).padding(8.dp))
                    }
                }
            }
            ComparisonMode.SPLIT_SLIDER -> {
                val splitX = (containerWidth * sliderPosition).coerceIn(0f, containerWidth)

                // Draw Split Views on Canvas
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(containerWidth) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                val newPos = (change.position.x / containerWidth).coerceIn(0.05f, 0.95f)
                                onSliderChange(newPos)
                            }
                        }
                        .pointerInput(containerWidth) {
                            detectTapGestures { tapOffset ->
                                val newPos = (tapOffset.x / containerWidth).coerceIn(0.05f, 0.95f)
                                onSliderChange(newPos)
                            }
                        }
                ) {
                    val fullSize = IntSize(containerWidth.roundToInt(), containerHeight.roundToInt())

                    // 1. Draw Cleaned (After) Image on the right side
                    clipRect(left = splitX, top = 0f, right = containerWidth, bottom = containerHeight) {
                        drawImage(image = afterImage, dstSize = fullSize)
                    }

                    // 2. Draw Original (Before) Image on the left side
                    clipRect(left = 0f, top = 0f, right = splitX, bottom = containerHeight) {
                        drawImage(image = beforeImage, dstSize = fullSize)
                    }

                    // 3. Draw dividing glowing vertical bar
                    drawLine(
                        color = Color.White,
                        start = Offset(splitX, 0f),
                        end = Offset(splitX, containerHeight),
                        strokeWidth = 3.dp.toPx()
                    )
                }

                // Badges
                BadgeTag(
                    text = "ORIGINAL",
                    color = AmberWarning,
                    modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
                )
                BadgeTag(
                    text = "CLEANED",
                    color = EmeraldSuccess,
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                )

                // Drag Thumb Handle at split position
                Box(
                    modifier = Modifier
                        .offset {
                            IntOffset(
                                x = (splitX - 22.dp.roundToPx()).roundToInt(),
                                y = ((containerHeight / 2f) - 22.dp.roundToPx()).roundToInt()
                            )
                        }
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .border(2.dp, CyanPrimary, CircleShape)
                        .pointerInput(containerWidth) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                val newPos = (change.position.x / containerWidth).coerceIn(0.05f, 0.95f)
                                onSliderChange(newPos)
                            }
                        }
                        .testTag("slider_handle"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.CompareArrows,
                        contentDescription = "Slide to compare",
                        tint = DarkBackground,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun BadgeTag(
    text: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.Black.copy(alpha = 0.75f),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.8f)),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}
