package com.example.ai

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import com.example.model.BrushStroke
import com.example.model.NormalizedRect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

object InpaintingEngine {

    /**
     * Creates a binary mask bitmap (White = inpaint area, Black = keep area).
     */
    fun createMask(
        width: Int,
        height: Int,
        regions: List<NormalizedRect>,
        brushStrokes: List<BrushStroke>
    ): Bitmap {
        val mask = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(mask)
        canvas.drawColor(Color.BLACK)

        val fillPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        // 1. Draw bounding boxes with slight margin padding to ensure complete coverage of watermark edges
        for (region in regions) {
            val padX = region.width * 0.04f
            val padY = region.height * 0.04f
            val left = ((region.left - padX).coerceAtLeast(0f) * width)
            val top = ((region.top - padY).coerceAtLeast(0f) * height)
            val right = ((region.right + padX).coerceAtMost(1f) * width)
            val bottom = ((region.bottom + padY).coerceAtMost(1f) * height)
            canvas.drawRect(left, top, right, bottom, fillPaint)
        }

        // 2. Draw user brush strokes
        for (stroke in brushStrokes) {
            if (stroke.points.isEmpty()) continue
            val strokePaint = Paint().apply {
                color = if (stroke.isEraser) Color.BLACK else Color.WHITE
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
                strokeWidth = stroke.strokeRadiusNormalized * 2f * min(width, height)
                isAntiAlias = true
            }

            if (stroke.points.size == 1) {
                val pt = stroke.points[0]
                val capPaint = Paint().apply {
                    color = if (stroke.isEraser) Color.BLACK else Color.WHITE
                    style = Paint.Style.FILL
                }
                canvas.drawCircle(
                    pt.x * width,
                    pt.y * height,
                    stroke.strokeRadiusNormalized * min(width, height),
                    capPaint
                )
            } else {
                val path = Path()
                path.moveTo(stroke.points[0].x * width, stroke.points[0].y * height)
                for (i in 1 until stroke.points.size) {
                    val p = stroke.points[i]
                    path.lineTo(p.x * width, p.y * height)
                }
                canvas.drawPath(path, strokePaint)
            }
        }

        return mask
    }

    /**
     * Executes high-quality content-aware inpainting using boundary-sampling,
     * gradient interpolation, and micro-texture grain blending.
     */
    suspend fun inpaint(
        source: Bitmap,
        regions: List<NormalizedRect>,
        brushStrokes: List<BrushStroke> = emptyList(),
        onProgress: ((Float) -> Unit)? = null
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = source.width
        val height = source.height

        val mask = createMask(width, height, regions, brushStrokes)
        val result = source.copy(Bitmap.Config.ARGB_8888, true)

        val srcPixels = IntArray(width * height)
        val maskPixels = IntArray(width * height)
        val outPixels = IntArray(width * height)

        source.getPixels(srcPixels, 0, width, 0, 0, width, height)
        mask.getPixels(maskPixels, 0, width, 0, 0, width, height)
        System.arraycopy(srcPixels, 0, outPixels, 0, srcPixels.size)

        // Find bounding box of all mask pixels to speed up processing
        var minX = width
        var maxX = 0
        var minY = height
        var maxY = 0
        var hasMask = false

        for (y in 0 until height) {
            val rowOffset = y * width
            for (x in 0 until width) {
                // If red channel > 128, it's marked for inpainting
                if ((maskPixels[rowOffset + x] and 0x00FF0000) shr 16 > 128) {
                    hasMask = true
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }

        if (!hasMask) {
            mask.recycle()
            return@withContext result
        }

        // Expand bounds slightly for context
        val pad = 16
        minX = max(0, minX - pad)
        maxX = min(width - 1, maxX + pad)
        minY = max(0, minY - pad)
        maxY = min(height - 1, maxY + pad)

        // Identify boundary pixels (pixels just outside the mask)
        data class BoundaryPixel(val x: Int, val y: Int, val r: Float, val g: Float, val b: Float)
        val boundaryList = ArrayList<BoundaryPixel>()

        val step = max(1, (maxX - minX) / 120)
        for (y in minY..maxY step step) {
            for (x in minX..maxX step step) {
                val idx = y * width + x
                val isMask = (maskPixels[idx] and 0x00FF0000) shr 16 > 128
                if (!isMask) {
                    // Check if adjacent to mask
                    var isNearMask = false
                    val checkRad = step * 2
                    for (dy in -checkRad..checkRad step step) {
                        val cy = y + dy
                        if (cy !in 0 until height) continue
                        for (dx in -checkRad..checkRad step step) {
                            val cx = x + dx
                            if (cx !in 0 until width) continue
                            if ((maskPixels[cy * width + cx] and 0x00FF0000) shr 16 > 128) {
                                isNearMask = true
                                break
                            }
                        }
                        if (isNearMask) break
                    }
                    if (isNearMask) {
                        val c = srcPixels[idx]
                        val r = ((c shr 16) and 0xFF).toFloat()
                        val g = ((c shr 8) and 0xFF).toFloat()
                        val b = (c and 0xFF).toFloat()
                        boundaryList.add(BoundaryPixel(x, y, r, g, b))
                    }
                }
            }
        }

        // Inpaint each masked pixel using Inverse Distance Weighting with directional bias
        val totalRows = (maxY - minY + 1)
        val random = Random(42)

        for (y in minY..maxY) {
            val rowOffset = y * width
            for (x in minX..maxX) {
                val idx = rowOffset + x
                if ((maskPixels[idx] and 0x00FF0000) shr 16 > 128) {
                    var sumR = 0f
                    var sumG = 0f
                    var sumB = 0f
                    var totalWeight = 0f

                    // Sample boundary pixels
                    var samples = 0
                    for (bp in boundaryList) {
                        val dx = (x - bp.x).toFloat()
                        val dy = (y - bp.y).toFloat()
                        val distSq = dx * dx + dy * dy
                        if (distSq < 1f) continue

                        // Weight falls off with distance^2.2 for smooth natural falloff
                        val dist = hypot(dx, dy)
                        val w = 1f / (dist * dist + 1f)

                        sumR += bp.r * w
                        sumG += bp.g * w
                        sumB += bp.b * w
                        totalWeight += w
                        samples++
                    }

                    if (totalWeight > 0f) {
                        var finalR = (sumR / totalWeight)
                        var finalG = (sumG / totalWeight)
                        var finalB = (sumB / totalWeight)

                        // Subtle micro-grain noise injection (+/- 2.5) to match digital sensor texture
                        val noise = (random.nextFloat() - 0.5f) * 5f
                        finalR = (finalR + noise).coerceIn(0f, 255f)
                        finalG = (finalG + noise).coerceIn(0f, 255f)
                        finalB = (finalB + noise).coerceIn(0f, 255f)

                        outPixels[idx] = (0xFF shl 24) or
                                (finalR.toInt() shl 16) or
                                (finalG.toInt() shl 8) or
                                finalB.toInt()
                    }
                }
            }
            if (y % 20 == 0) {
                onProgress?.invoke((y - minY).toFloat() / totalRows)
            }
        }

        result.setPixels(outPixels, 0, width, 0, 0, width, height)
        mask.recycle()
        onProgress?.invoke(1f)
        result
    }
}
