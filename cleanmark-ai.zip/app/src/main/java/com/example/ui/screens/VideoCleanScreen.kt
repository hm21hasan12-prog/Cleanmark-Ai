package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.ComparisonMode
import com.example.model.NormalizedRect
import com.example.ui.components.BeforeAfterSlider
import com.example.ui.components.ProcessingOverlay
import com.example.ui.components.WatermarkCanvasOverlay
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.VioletSecondary
import com.example.viewmodel.CleanMarkViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoCleanScreen(
    viewModel: CleanMarkViewModel,
    modifier: Modifier = Modifier
) {
    val frames by viewModel.videoFrames.collectAsStateWithLifecycle()
    val cleanedFrames by viewModel.cleanedVideoFrames.collectAsStateWithLifecycle()
    val currentFrameIndex by viewModel.currentVideoFrame.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isVideoPlaying.collectAsStateWithLifecycle()
    val videoRegions by viewModel.videoRegions.collectAsStateWithLifecycle()
    val processingState by viewModel.processingState.collectAsStateWithLifecycle()
    val sliderPos by viewModel.sliderPosition.collectAsStateWithLifecycle()

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { viewModel.loadVideoFromUri(it) }
    }

    val currentOriginalFrame = frames.getOrNull(currentFrameIndex)
    val currentCleanedFrame = cleanedFrames.getOrNull(currentFrameIndex)

    Box(modifier = modifier.fillMaxSize().background(DarkBackground)) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Video Watermark Remover",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = if (cleanedFrames.isNotEmpty()) "Cleaned Video Sequence (${cleanedFrames.size} frames)" else "Video Timeline (${frames.size} frames)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    // Pick Video
                    IconButton(
                        onClick = {
                            videoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        },
                        modifier = Modifier.testTag("pick_video_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VideoFile,
                            contentDescription = "Import Video",
                            tint = CyanPrimary
                        )
                    }

                    // Reload Sample Video
                    IconButton(
                        onClick = { viewModel.loadSampleVideo() },
                        modifier = Modifier.testTag("reload_sample_video_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset Demo Video",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )

            // Preset Quick Select Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Watermark Position:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FilterChip(
                    selected = videoRegions.any { it.top < 0.2f && it.right > 0.8f },
                    onClick = {
                        viewModel.updateVideoRegion(
                            NormalizedRect(top = 0.04f, left = 0.68f, bottom = 0.18f, right = 0.96f)
                        )
                    },
                    label = { Text("Top-Right Logo") }
                )
                FilterChip(
                    selected = videoRegions.any { it.top > 0.8f },
                    onClick = {
                        viewModel.updateVideoRegion(
                            NormalizedRect(top = 0.88f, left = 0.60f, bottom = 0.98f, right = 0.98f)
                        )
                    },
                    label = { Text("Timestamp") }
                )
            }

            // Main Video Viewport (Player with Split-Screen Slider if cleaned, or Watermark Overlay)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                if (currentOriginalFrame != null) {
                    if (currentCleanedFrame != null) {
                        // Before & After Video Comparison Slider
                        BeforeAfterSlider(
                            beforeBitmap = currentOriginalFrame,
                            afterBitmap = currentCleanedFrame,
                            sliderPosition = sliderPos,
                            onSliderChange = { viewModel.setSliderPosition(it) },
                            comparisonMode = ComparisonMode.SPLIT_SLIDER,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        // Original Frame with Watermark Region Highlighting
                        WatermarkCanvasOverlay(
                            bitmap = currentOriginalFrame,
                            regions = videoRegions.map {
                                com.example.model.WatermarkRegion(
                                    label = "Video Watermark Badge",
                                    type = com.example.model.WatermarkType.LOGO,
                                    rect = it,
                                    isSelected = true
                                )
                            },
                            brushStrokes = emptyList(),
                            cleanMode = com.example.model.CleanMode.AUTO_SCAN,
                            brushRadius = 0.035f,
                            isEraser = false,
                            onRegionToggle = {},
                            onAddBrushStroke = {},
                            onAddBoxRegion = { viewModel.updateVideoRegion(it) },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            // Video Player Timeline Controls
            Surface(
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Play / Pause Button
                        IconButton(
                            onClick = { viewModel.toggleVideoPlay() },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(CyanPrimary)
                                .testTag("video_play_pause_button")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = Color.Black
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Frame scrubber slider
                        val maxFrame = (if (cleanedFrames.isNotEmpty()) cleanedFrames.size else frames.size) - 1
                        Slider(
                            value = currentFrameIndex.toFloat(),
                            onValueChange = { viewModel.seekVideoFrame(it.toInt()) },
                            valueRange = 0f..maxFrame.coerceAtLeast(1).toFloat(),
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = CyanPrimary,
                                activeTrackColor = CyanPrimary
                            )
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = "${currentFrameIndex + 1}/${maxFrame + 1}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Keyframe Strip Thumbnails
                    val displayFrames = if (cleanedFrames.isNotEmpty()) cleanedFrames else frames
                    LazyRow(
                        contentPadding = PaddingValues(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        itemsIndexed(displayFrames) { idx, frame ->
                            Box(
                                modifier = Modifier
                                    .size(width = 54.dp, height = 36.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .border(
                                        width = if (idx == currentFrameIndex) 2.dp else 1.dp,
                                        color = if (idx == currentFrameIndex) CyanPrimary else Color.Transparent,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable { viewModel.seekVideoFrame(idx) }
                            ) {
                                androidx.compose.foundation.Image(
                                    bitmap = remember(frame) { frame.asImageBitmap() },
                                    contentDescription = "Frame $idx",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Action Bar: "Clean Video Watermarks"
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { viewModel.cleanVideo() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("clean_video_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (cleanedFrames.isNotEmpty()) EmeraldSuccess else CyanPrimary,
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (cleanedFrames.isNotEmpty()) "Re-Process Video Frames" else "AI Clean All Video Frames (${frames.size})",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        ProcessingOverlay(state = processingState)
    }
}
