package com.example

import android.graphics.Bitmap
import com.example.ai.InpaintingEngine
import com.example.model.NormalizedRect
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class InpaintingEngineTest {

    @Test
    fun testNormalizedRectCalculation() {
        val rect = NormalizedRect(top = 0.1f, left = 0.2f, bottom = 0.4f, right = 0.6f)
        assertEquals(0.4f, rect.width, 0.001f)
        assertEquals(0.3f, rect.height, 0.001f)
        assertTrue(rect.contains(0.3f, 0.25f))

        val pixelRect = rect.toPixelRect(100, 100)
        assertEquals(20, pixelRect.left)
        assertEquals(10, pixelRect.top)
        assertEquals(60, pixelRect.right)
        assertEquals(40, pixelRect.bottom)
    }

    @Test
    fun testInpaintingProducesValidBitmap() = runBlocking {
        val testBmp = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
        testBmp.eraseColor(android.graphics.Color.BLUE)

        val regions = listOf(NormalizedRect(0.2f, 0.2f, 0.5f, 0.5f))
        val result = InpaintingEngine.inpaint(testBmp, regions)

        assertNotNull(result)
        assertEquals(100, result.width)
        assertEquals(100, result.height)
    }
}
