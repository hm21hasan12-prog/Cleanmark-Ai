package com.example.data.local

import android.content.Context
import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class CleanItemRepository(
    private val dao: CleanItemDao,
    private val context: Context
) {
    val allCleanedItems: Flow<List<CleanItemEntity>> = dao.getAllCleanedItems()

    suspend fun saveCleanedImage(
        originalBitmap: Bitmap,
        cleanedBitmap: Bitmap,
        title: String,
        watermarkTags: String,
        watermarksRemoved: Int
    ): CleanItemEntity = withContext(Dispatchers.IO) {
        val storageDir = File(context.filesDir, "cleaned_media").apply { mkdirs() }
        val timestamp = System.currentTimeMillis()

        val origFile = File(storageDir, "orig_${timestamp}.jpg")
        FileOutputStream(origFile).use { out ->
            originalBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }

        val cleanFile = File(storageDir, "clean_${timestamp}.jpg")
        FileOutputStream(cleanFile).use { out ->
            cleanedBitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }

        val entity = CleanItemEntity(
            title = title,
            mediaType = "IMAGE",
            originalPath = origFile.absolutePath,
            cleanedPath = cleanFile.absolutePath,
            watermarkTags = watermarkTags,
            watermarksRemoved = watermarksRemoved,
            timestamp = timestamp
        )

        val id = dao.insertItem(entity)
        entity.copy(id = id)
    }

    suspend fun saveCleanedVideo(
        title: String,
        originalPath: String,
        cleanedPath: String,
        watermarkTags: String,
        watermarksRemoved: Int,
        durationSeconds: Double
    ): CleanItemEntity = withContext(Dispatchers.IO) {
        val entity = CleanItemEntity(
            title = title,
            mediaType = "VIDEO",
            originalPath = originalPath,
            cleanedPath = cleanedPath,
            watermarkTags = watermarkTags,
            watermarksRemoved = watermarksRemoved,
            durationSeconds = durationSeconds,
            timestamp = System.currentTimeMillis()
        )
        val id = dao.insertItem(entity)
        entity.copy(id = id)
    }

    suspend fun delete(item: CleanItemEntity) = withContext(Dispatchers.IO) {
        try {
            File(item.originalPath).delete()
            File(item.cleanedPath).delete()
        } catch (_: Exception) {}
        dao.deleteItem(item)
    }
}
